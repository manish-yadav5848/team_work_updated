import setuptools
from setuptools import setup

setup(
    name='voya_wealthcentral',
    version="0.1.0",
    author="lumiq",
    description='wheel file for voya wealthcentral project',
    packages=setuptools.find_packages(),
    include_package_data=True,
    package_data={
        '': [
            'conf/.env.accp',
            'conf/.env.dev',
            'conf/.env.intg',
            'conf/.env.prod',
            'conf/.env.unit',
            'conf/consumption_config.json',
            'conf/file_config.json',
            'conf/logging_config.yaml',
            'conf/transform_config.json',
        ]
    },
    install_requires=[
        'delta>=0.4.2',
        'delta-spark>=2.3.0',
        'importlib-metadata>=6.3.0',
        'pip>=23.0.1',
        'py4j>=0.10.9.5',
        'pyspark>=3.3.2',
        'python-dotenv>=1.0.0',
        'PyYAML>=6.0',
        'setuptools>=65.5.1',
        'simplejson>=3.18.4',
        'spark>=0.2.1',
        'wheel>=0.38.4',
        'zipp>=3.15.0',
        'DBUtils>=3.0.2'
    ]
)
